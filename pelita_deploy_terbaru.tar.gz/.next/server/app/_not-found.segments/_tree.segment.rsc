:HL["/_next/static/chunks/24yab3kjydgo2.css","style"]
:HL["/_next/static/chunks/3opyu1e7tl5qt.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"NtxdzAjCfJ-xaxUKtdM5-"}
