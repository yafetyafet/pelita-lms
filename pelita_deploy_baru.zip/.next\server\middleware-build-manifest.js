globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/lMNoDSyiZBrD7YoFFCq9F/_buildManifest.js",
    "static/lMNoDSyiZBrD7YoFFCq9F/_ssgManifest.js",
    "static/lMNoDSyiZBrD7YoFFCq9F/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/1c6aptmytnu6q.js",
    "static/chunks/3rn5xu1nx1tsv.js",
    "static/chunks/3kmozkq6tgqnz.js",
    "static/chunks/136t3-slxdx1_.js",
    "static/chunks/turbopack-13cmnzbzlj-np.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
