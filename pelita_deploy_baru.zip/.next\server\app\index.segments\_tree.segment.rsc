:HL["/_next/static/chunks/24yab3kjydgo2.css","style"]
:HL["/_next/static/chunks/0xlmln4cu66xu.css","style"]
:HL["/_next/static/media/fba5a26ea33df6a3-s.p.18rizl4rsrl42.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"lMNoDSyiZBrD7YoFFCq9F"}
